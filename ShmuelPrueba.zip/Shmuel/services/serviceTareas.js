import { getUsuario } from "../js/auth.js";
const url = "http://localhost:3000/"


export async function serviceMisTareas() {
    const usuario = getUsuario();
    try {
        const response = await fetch(`${url}tareas?id_user=${usuario.id}`);
        const tareas = await response.json();
        return tareas || []; 
    } catch (error) {
        return [];
    }
}


export async function serviceObtenerTodasLasTareas() {
    try {
        const response = await fetch(`${url}tareas`);
        if (!response.ok) throw new Error("Error API");
        return await response.json();
    } catch (error) {
        console.error("Error al obtener todas las tareas:", error);
        return [];
    }
}

// NUEVA TAREA
export async function serviceCrearTarea(nuevaTarea) {
    try {
        const response = await fetch(`${url}tareas`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nuevaTarea)
        });
        if (!response.ok) throw new Error("Error al crear la tarea en el servidor");
        return await response.json();
    } catch (error) {
        console.error(error);
        throw error;
    }
}

// ELIMINAR TAREA
export async function serviceEliminarTarea(id) {
    try {
        const response = await fetch(`${url}tareas/${id}`, {
            method: 'DELETE',
        });
        if (!response.ok) throw new Error("No se pudo eliminar la tarea");
        return true;
    } catch (error) {
        console.error(error);
        throw error;
    }
}


export async function serviceCambiarStatus(id, nuevoStatus) {
    try {
        const response = await fetch(`${url}tareas/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: nuevoStatus })
        });
        if (!response.ok) throw new Error("Error al actualizar estado");
        return await response.json();
    } catch (error) {
        console.error(error);
    }
}

