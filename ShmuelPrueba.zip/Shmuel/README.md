# CRUDZASO - Task Manager System
Este proyecto es un sistema de gestión de tareas modular construido con JavaScript puro (Vanilla JS), diseñado para separar la lógica de negocio de la interfaz de usuario. Utiliza Tailwind CSS para el diseño y JSON Server como motor de base de datos para simular una API REST funcional.

## Arquitectura del Proyecto
El sistema se basa en una división estricta de responsabilidades para mantener el código ordenado y escalable:

```
├── css/    
│   └── style.css          
│   └── menu.css          
│   └── formulario.css        
│   └── dashboard.css          
├── js/
│   ├── auth.js           
│   ├── elements.js       
│   ├── listeners.js      
│   ├── main.js           
│   ├── render.js         
│   └── renderAdmin.js    
├── services/
│   ├── serviceUsuario.js    
│   └── serviceTareas.js     
├── pages/
│   ├── dashboard.html       
│   └── menu.html            
├──api/
│   ├── db.json  
└── index.html

```

## El sistema implementa un control de acceso sencillo pero efectivo:

1. **Vista de Usuario:** El acceso está limitado a sus propias tareas. Puede crear nuevas entradas, buscar por texto y rotar el estado de sus pendientes haciendo clic en el badge correspondiente.

1. **Vista de Administrador:** Posee un panel de control global. Puede visualizar el total de tareas de todos los usuarios del sistema, supervisar métricas de cumplimiento y eliminar o editar cualquier registro sin restricciones.

## Instalación y Uso
Para ejecutar este proyecto en un entorno local, sigue estos pasos:

1. Servidor de Datos: Es necesario tener instalado JSON Server. Puedes iniciarlo con el siguiente comando en la terminal:

1. json-server --watch db.json --port 3000
Servidor Web: Abre el proyecto utilizando un servidor local como Live Server para que los módulos de JavaScript (ES6) funcionen correctamente por razones de seguridad del navegador.

## Credenciales
El sistema utiliza el campo is_admin dentro del objeto de usuario en el archivo db.json para definir el acceso a las rutas /pages/menu.html o /pages/dashboard.html.

## Funciones Técnicas Destacadas
Delegación de Eventos: En lugar de asignar un evento a cada botón de la tabla, se asigna uno solo al cuerpo de la tabla (tbody) para mejorar el rendimiento y asegurar que los botones funcionen incluso después de filtrar o recargar los datos.

## Rotación de Status:
Implementación de ciclos lógicos para que el estado de una tarea cambie de Pending a In Progress y luego a Completed con un solo clic, actualizando la base de datos mediante el método PATCH.

## Filtros Combinados
El motor de búsqueda permite filtrar simultáneamente por texto y por estado sin perder la integridad de los datos originales.


## Cuenta User
**user:** asd@asd.asd
**password:** asd123

## Cuenta Admin
**user:** dsa@dsa.dsa
**password:** dsa123